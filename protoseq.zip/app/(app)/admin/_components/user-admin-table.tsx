'use client';

import { useState, useTransition, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import {
  Select, SelectContent, SelectItem, SelectTrigger,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Trash2, Link2, Check } from 'lucide-react';
import { initials, formatRelative } from '@/lib/utils/format';
import { updateUser, resendAccessLink } from '../actions';
import { DeleteUserDialog } from './delete-user-dialog';

type Profile = {
  id: string;
  email: string;
  full_name: string | null;
  role: 'super_admin' | 'admin' | 'manager' | 'rep';
  manager_id: string | null;
  region_id: string | null;
  is_active: boolean;
  created_at: string;
};

const ROLE_LABELS: Record<string, string> = {
  super_admin: 'Super Admin',
  admin: 'Admin',
  manager: 'Manager',
  rep: 'Rep',
};

export function UserAdminTable({
  profiles,
  regions,
  currentUserId,
  currentRole,
}: {
  profiles: Profile[];
  regions: { id: string; name: string; code: string }[];
  currentUserId: string;
  currentRole: string;
}) {
  const router = useRouter();
  const [search, setSearch] = useState('');
  const [pendingId, setPendingId] = useState<string | null>(null);
  const [, startTransition] = useTransition();
  const [deleteTarget, setDeleteTarget] = useState<Profile | null>(null);
  const [linking, setLinking] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  async function makeLink(email: string) {
    setLinking(email);
    const res = await resendAccessLink({ email });
    setLinking(null);
    if (res.ok === false) {
      toast.error(res.message, { duration: 8000 });
      return;
    }
    try {
      await navigator.clipboard.writeText(res.url);
      setCopied(email);
      setTimeout(() => setCopied(null), 4000);
      toast.success(
        res.setsPassword
          ? 'Link copied. They have no password yet, so it takes them straight to set one.'
          : 'Link copied. Signs them in and lets them reset their password.',
        { duration: 8000 },
      );
    } catch {
      // Clipboard is blocked outside a secure context and on some mobile
      // browsers. Showing the link beats silently doing nothing.
      toast.message('Copy this link', { description: res.url, duration: 60000 });
    }
  }

  const filtered = useMemo(() => {
    if (!search.trim()) return profiles;
    const q = search.toLowerCase();
    return profiles.filter(p =>
      (p.full_name || '').toLowerCase().includes(q) ||
      p.email.toLowerCase().includes(q)
    );
  }, [profiles, search]);

  const managerCandidates = profiles.filter(p =>
    p.role === 'manager' || p.role === 'admin' || p.role === 'super_admin'
  );

  const successorCandidates = profiles.filter(p => p.is_active);

  function patch(id: string, updates: Parameters<typeof updateUser>[1]) {
    setPendingId(id);
    startTransition(async () => {
      try {
        await updateUser(id, updates);
        toast.success('Updated');
        router.refresh();
      } catch (err) {
        toast.error(err instanceof Error ? err.message : 'Failed');
      } finally {
        setPendingId(null);
      }
    });
  }

  function canDelete(target: Profile): boolean {
    if (target.id === currentUserId) return false;
    if (currentRole === 'super_admin') return true;
    if (currentRole === 'admin') return target.role !== 'admin' && target.role !== 'super_admin';
    if (currentRole === 'manager') return target.role === 'rep';  // managers only delete reps
    return false;
  }

  return (
    <>
      <div className="mb-5">
        <Input
          placeholder="Search users…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="md:max-w-xs"
        />
      </div>

      {/* DESKTOP TABLE */}
      <div className="hidden md:block card-lit border border-border/40 rounded-md overflow-hidden">
        <div className="grid grid-cols-[2fr_1fr_1.2fr_1fr_0.8fr_0.8fr_60px] items-center gap-4 px-5 py-3 text-[10px] uppercase tracking-[0.15em] text-muted-foreground border-b border-border/40 bg-background/30">
          <div>User</div>
          <div>Role</div>
          <div>Manager</div>
          <div>Region</div>
          <div>Status</div>
          <div className="text-right">Joined</div>
          <div></div>
        </div>
        {filtered.map(p => {
          const isSelf = p.id === currentUserId;
          const isPending = pendingId === p.id;
          const managerName = profiles.find(m => m.id === p.manager_id)?.full_name;
          const deletable = canDelete(p);
          return (
            <div key={p.id} className="grid grid-cols-[2fr_1fr_1.2fr_1fr_0.8fr_0.8fr_60px] items-center gap-4 px-5 py-4 border-b border-border/20 last:border-0">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 rounded-full bg-primary/15 text-primary text-xs font-medium flex items-center justify-center shrink-0">
                  {initials(p.full_name, p.email)}
                </div>
                <div className="min-w-0">
                  <div className="font-medium truncate">
                    {p.full_name || p.email.split('@')[0]}
                    {isSelf && <span className="ml-2 text-[10px] uppercase text-primary tracking-[0.15em]">you</span>}
                  </div>
                  <div className="text-xs text-muted-foreground truncate">{p.email}</div>
                </div>
              </div>

              <Select
                value={p.role}
                disabled={isPending || (isSelf && p.role === currentRole)}
                onValueChange={(v: string | null) => v && patch(p.id, { role: v as Profile['role'] })}
              >
                <SelectTrigger className="h-9"><span>{ROLE_LABELS[p.role]}</span></SelectTrigger>
                <SelectContent>
                  <SelectItem value="rep">Rep</SelectItem>
                  <SelectItem value="manager">Manager</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                  {currentRole === 'super_admin' && <SelectItem value="super_admin">Super Admin</SelectItem>}
                </SelectContent>
              </Select>

              <Select
                value={p.manager_id || 'none'}
                disabled={isPending}
                onValueChange={(v: string | null) => patch(p.id, { manager_id: !v || v === 'none' ? null : v })}
              >
                <SelectTrigger className="h-9">
                  <span className={managerName ? '' : 'text-muted-foreground'}>{managerName || 'No manager'}</span>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— None —</SelectItem>
                  {managerCandidates.filter(m => m.id !== p.id).map(m => (
                    <SelectItem key={m.id} value={m.id}>{m.full_name || m.email}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={p.region_id || 'none'}
                disabled={isPending}
                onValueChange={(v: string | null) => patch(p.id, { region_id: !v || v === 'none' ? null : v })}
              >
                <SelectTrigger className="h-9">
                  <span className={p.region_id ? '' : 'text-muted-foreground'}>
                    {regions.find(r => r.id === p.region_id)?.code || 'All regions'}
                  </span>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">All regions (corporate)</SelectItem>
                  {regions.map(r => (
                    <SelectItem key={r.id} value={r.id}>{r.code} - {r.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <button
                type="button"
                disabled={isPending || isSelf}
                onClick={() => patch(p.id, { is_active: !p.is_active })}
                className={`inline-flex items-center justify-center px-2.5 py-1 rounded-md text-[10px] uppercase tracking-[0.12em] border transition-colors min-h-[32px] ${
                  p.is_active
                    ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/15'
                    : 'border-muted-foreground/30 bg-muted/30 text-muted-foreground hover:bg-muted/50'
                } ${isSelf ? 'cursor-not-allowed opacity-60' : ''}`}
              >
                {p.is_active ? 'Active' : 'Inactive'}
              </button>

              <div className="text-xs text-muted-foreground text-right tabular-nums">
                {formatRelative(p.created_at)}
              </div>

              <div className="flex items-center gap-1 justify-self-end">
                {/* A fresh sign-in link for somebody who already exists.
                    Without this the only way back in was deleting and
                    recreating the person, which churns their auth user. */}
                <button
                  type="button"
                  disabled={linking === p.email}
                  onClick={() => makeLink(p.email)}
                  className="h-8 w-8 inline-flex items-center justify-center rounded-md text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors disabled:opacity-50"
                  aria-label={`Copy a sign-in link for ${p.full_name || p.email}`}
                  title="Copy a fresh sign-in link"
                >
                  {copied === p.email ? (
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                  ) : (
                    <Link2 className="h-3.5 w-3.5" />
                  )}
                </button>
              {deletable ? (
                <button
                  type="button"
                  onClick={() => setDeleteTarget(p)}
                  className="h-8 w-8 inline-flex items-center justify-center rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors justify-self-end"
                  aria-label={`Delete ${p.full_name || p.email}`}
                  title="Delete user"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              ) : null}
              </div>
            </div>
          );
        })}
        {filtered.length === 0 && (
          <div className="px-5 py-12 text-center text-sm text-muted-foreground">
            No users match.
          </div>
        )}
      </div>

      {/* MOBILE CARDS */}
      <div className="md:hidden space-y-3">
        {filtered.map(p => {
          const isSelf = p.id === currentUserId;
          const isPending = pendingId === p.id;
          const managerName = profiles.find(m => m.id === p.manager_id)?.full_name;
          const deletable = canDelete(p);
          return (
            <div key={p.id} className="card-lit border border-border/40 rounded-md p-4 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/15 text-primary text-xs font-medium flex items-center justify-center shrink-0">
                  {initials(p.full_name, p.email)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium leading-tight truncate">
                    {p.full_name || p.email.split('@')[0]}
                    {isSelf && <span className="ml-2 text-[10px] uppercase text-primary tracking-[0.15em]">you</span>}
                  </div>
                  <div className="text-[11px] text-muted-foreground truncate">{p.email}</div>
                </div>
                {deletable && (
                  <button
                    type="button"
                    onClick={() => setDeleteTarget(p)}
                    className="h-9 w-9 inline-flex items-center justify-center rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                    aria-label="Delete user"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>

              <button
                type="button"
                disabled={linking === p.email}
                onClick={() => makeLink(p.email)}
                className="w-full inline-flex items-center justify-center gap-2 rounded-md border border-border/40 px-3 py-2.5 text-xs text-muted-foreground transition-colors hover:text-primary disabled:opacity-50"
              >
                {copied === p.email ? (
                  <><Check className="h-3.5 w-3.5 text-emerald-400" /> Copied</>
                ) : (
                  <><Link2 className="h-3.5 w-3.5" /> {linking === p.email ? 'Making a link...' : 'Copy sign-in link'}</>
                )}
              </button>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="text-[10px] uppercase tracking-[0.15em] text-muted-foreground mb-1">Role</div>
                  <Select
                    value={p.role}
                    disabled={isPending || (isSelf && p.role === currentRole)}
                    onValueChange={(v: string | null) => v && patch(p.id, { role: v as Profile['role'] })}
                  >
                    <SelectTrigger className="h-9"><span>{ROLE_LABELS[p.role]}</span></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="rep">Rep</SelectItem>
                      <SelectItem value="manager">Manager</SelectItem>
                      <SelectItem value="admin">Admin</SelectItem>
                      {currentRole === 'super_admin' && <SelectItem value="super_admin">Super Admin</SelectItem>}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-[0.15em] text-muted-foreground mb-1">Manager</div>
                  <Select
                    value={p.manager_id || 'none'}
                    disabled={isPending}
                    onValueChange={(v: string | null) => patch(p.id, { manager_id: !v || v === 'none' ? null : v })}
                  >
                    <SelectTrigger className="h-9">
                      <span className={managerName ? '' : 'text-muted-foreground'}>{managerName || 'None'}</span>
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">— None —</SelectItem>
                      {managerCandidates.filter(m => m.id !== p.id).map(m => (
                        <SelectItem key={m.id} value={m.id}>{m.full_name || m.email}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="col-span-2">
                  <div className="text-[10px] uppercase tracking-[0.15em] text-muted-foreground mb-1">Region</div>
                  <Select
                    value={p.region_id || 'none'}
                    disabled={isPending}
                    onValueChange={(v: string | null) => patch(p.id, { region_id: !v || v === 'none' ? null : v })}
                  >
                    <SelectTrigger className="h-9">
                      <span className={p.region_id ? '' : 'text-muted-foreground'}>
                        {regions.find(r => r.id === p.region_id)?.name || 'All regions'}
                      </span>
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">All regions (corporate)</SelectItem>
                      {regions.map(r => (
                        <SelectItem key={r.id} value={r.id}>{r.code} - {r.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <button
                  type="button"
                  disabled={isPending || isSelf}
                  onClick={() => patch(p.id, { is_active: !p.is_active })}
                  className={`inline-flex items-center justify-center px-3 py-1.5 rounded-md text-[10px] uppercase tracking-[0.12em] border transition-colors min-h-[32px] ${
                    p.is_active
                      ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400'
                      : 'border-muted-foreground/30 bg-muted/30 text-muted-foreground'
                  } ${isSelf ? 'cursor-not-allowed opacity-60' : ''}`}
                >
                  {p.is_active ? 'Active' : 'Inactive'}
                </button>
                <span className="text-[10px] text-muted-foreground tabular-nums">
                  joined {formatRelative(p.created_at)}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      <DeleteUserDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        targetUser={deleteTarget}
        successorCandidates={successorCandidates}
      />
    </>
  );
}
