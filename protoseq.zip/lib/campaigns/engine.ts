// The campaign engine, ported from the local `npm run send` CLI so any
// NectarPay group can run their own sequence from the app. Every rule the
// CLI earned the hard way is preserved:
//   - engagement suppression (any non-view Pulse event ends the sequence)
//   - follow-ups before fresh opens, oldest stages first
//   - named leads before unnamed, both ordered by score (not alphabetically)
//   - one email per inbox per run, and sibling locations sharing that inbox
//     get marked contacted too (the Zen Leaf x5 lesson)
//   - native leads cap at e4; flagged leads get the native story while
//     keeping their locked vertical in the database
// Each org brings its OWN Resend key, so sending reputation stays theirs.

import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { DEFAULT_TZ, todayIn, daysBetween, type TimeZone } from '@/lib/db/tz';
import {
  renderEmail, maxStageFor, CLUSTER_MAP, DEFAULT_REP,
  type Cluster, type Rep, type Stage, type TemplateLead,
} from './templates';

export type CampaignSettings = {
  /** Primary key since 060. One campaign per region, not per org. */
  region_id: string;
  org_id: string;
  status: 'paused' | 'running';
  resend_api_key: string | null;
  from_domain: string | null;
  from_label: string | null;
  reply_to: string | null;
  physical_address: string | null;
  pulse_base_url: string | null;
  campaign_start: string;
  ramp: { throughDay: number; dailyCap: number }[];
  /** Send only to shops a rep actually owns, never to the unassigned reserve. */
  assigned_only?: boolean | null;
  followup_gap_days: Record<string, number>;
  send_delay_ms: number;
  last_run_at: string | null;
  // Launch scoping: when set, ONLY leads assigned to this rep are emailed.
  // Keeps the sequence and the CRM in sync - a rep should never get a
  // reply about a shop that isn't in their book.
  send_owner_id: string | null;
};

/** The region a campaign belongs to, as joined by the cron. */
export type CampaignRegion = {
  id: string;
  code: string;
  name: string;
  timezone: TimeZone;
  send_hour: number;
  is_active: boolean;
};

type LeadRow = TemplateLead & {
  place_id: string;
  emails: string[];
  band: string;
  score: number;
  status: string;
  email_stage: number;
  last_emailed_at: string | null;
  crypto_native: boolean | null;
};

export type PlanItem = {
  placeId: string;
  stage: Stage;
  to: string;
  name: string;
  vertical: string;
  band: string;
  repFirst: string;
};

export type RunResult = {
  planned: number;
  sent: number;
  failed: number;
  mix: Record<string, number>;
  note?: string;
};

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const cityShort = (city: string | null) => (city ?? 'Phoenix').replace(/\s+AZ$/, '');

export function serviceClient(): SupabaseClient {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY!;
  if (!url || !key) throw new Error('Missing Supabase service env vars');
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

// Campaign day counts in the REGION's calendar, not the server's. The old
// version subtracted timestamps and divided by 86,400,000, which drifts by a
// day near midnight and cannot survive a region on a different clock: the same
// instant is day 4 in Phoenix and day 5 in DFW. Comparing plain dates removes
// the arithmetic entirely.
export function campaignDay(s: CampaignSettings, tz: TimeZone = DEFAULT_TZ): number {
  if (!s.campaign_start) return 1;
  return Math.max(1, daysBetween(s.campaign_start, todayIn(tz)) + 1);
}

export function todaysCap(s: CampaignSettings, tz: TimeZone = DEFAULT_TZ): number {
  const day = campaignDay(s, tz);
  const ramp = s.ramp ?? [];
  for (const r of ramp) if (day <= r.throughDay) return r.dailyCap;
  return ramp.length ? ramp[ramp.length - 1].dailyCap : 30;
}

const SELECT =
  'place_id, name, city, vertical, vertical_label, owner_first_name, pulse_token, emails, band, score, status, email_stage, last_emailed_at, crypto_native';

/** Builds today's send plan without sending anything. */
export async function buildPlan(
  supabase: SupabaseClient,
  settings: CampaignSettings,
  tz: TimeZone = DEFAULT_TZ
): Promise<{ plan: { lead: LeadRow; stage: Stage }[]; repFor: (placeId: string) => Rep; cap: number }> {
  // Every pool read below is fenced to this campaign's region. Without the
  // fence a Phoenix run would happily email Fort Worth shops the moment DFW
  // leads land in nectarpay_leads, because the table is one shared pool.
  const region = settings.region_id;
  const cap = todaysCap(settings, tz);

  // Rep routing: CRM owner assignment decides who the email comes from
  const { data: repRows } = await supabase
    .from('reps')
    .select('profile_id, first_name, from_email, is_default, active')
    .eq('active', true);
  const repsById = new Map<string, Rep>(
    (repRows ?? []).map((r) => [r.profile_id, { first: r.first_name, fromEmail: r.from_email }])
  );
  const defaultRep: Rep =
    (repRows ?? []).filter((r) => r.is_default).map((r) => ({ first: r.first_name, fromEmail: r.from_email }))[0] ??
    DEFAULT_REP;

  // Paged deliberately: an unranged select caps at 1,000 rows, and any owner
  // past that silently falls through to the DEFAULT rep. That is how a whole
  // batch ends up sending as one person.
  const ownerByPlace = new Map<string, string>();
  for (let from = 0; ; from += 1000) {
    const { data: ownerRows } = await supabase
      .from('contacts')
      .select('legacy_id, owner_id')
      .eq('region_id', region)
      .not('legacy_id', 'is', null)
      .not('owner_id', 'is', null)
      .order('legacy_id')
      .range(from, from + 999);
    const rows = ownerRows ?? [];
    for (const c of rows) ownerByPlace.set(c.legacy_id as string, c.owner_id as string);
    if (rows.length < 1000) break;
  }
  const repFor = (placeId: string): Rep => {
    const ownerId = ownerByPlace.get(placeId);
    return (ownerId && repsById.get(ownerId)) || defaultRep;
  };

  // Any hard Pulse engagement ends the sequence - the lead is a rep's now
  // Paged. This was an unranged select, which PostgREST silently caps at
  // 1,000 rows - the fifth place in this app that trap has appeared. Under the
  // cap it looks perfect; over it, the oldest engaged leads fall out of the
  // suppression set and get cold-emailed again after raising their hand.
  const engagedTokens = new Set<string>();
  for (let from = 0; ; from += 1000) {
    const { data: engaged } = await supabase
      .from('engagement_events')
      .select('pulse_token')
      .neq('event', 'view')
      .order('pulse_token')
      .range(from, from + 999);
    const rows = engaged ?? [];
    for (const e of rows) engagedTokens.add(e.pulse_token as string);
    if (rows.length < 1000) break;
  }

  // Scope the pool. Two independent narrowings:
  //   send_owner_id  - one rep's book only
  //   assigned_only  - any rep's book, but never the unassigned reserve
  // Unranged PostgREST selects cap at 1,000 rows, and the assigned book is
  // already larger than that, so this pages explicitly. Silently truncating
  // here would look like 'the campaign skipped Joe's shops'.
  let scopeIds: string[] | null = null;
  if (settings.send_owner_id || settings.assigned_only) {
    const ids: string[] = [];
    const PAGE = 1000;
    for (let from = 0; ; from += PAGE) {
      const { data: page } = settings.send_owner_id
        ? await supabase
            .from('contacts')
            .select('legacy_id')
            .eq('region_id', region)
            .not('legacy_id', 'is', null)
            .eq('owner_id', settings.send_owner_id)
            .order('legacy_id')
            .range(from, from + PAGE - 1)
        : await supabase
            .from('contacts')
            .select('legacy_id')
            .eq('region_id', region)
            .not('legacy_id', 'is', null)
            .not('owner_id', 'is', null)
            .order('legacy_id')
            .range(from, from + PAGE - 1);
      const rows = page ?? [];
      for (const c of rows) ids.push(c.legacy_id as string);
      if (rows.length < PAGE) break;
    }
    scopeIds = ids;
    if (scopeIds.length === 0) return { plan: [], repFor, cap };
  }
  const scopeSet = scopeIds ? new Set(scopeIds) : null;
  const inScope = (l: { place_id: string }) => !scopeSet || scopeSet.has(l.place_id);

  const cutoff = (days: number) => new Date(Date.now() - days * 86400000).toISOString();
  const isNative = (l: LeadRow) => !!l.crypto_native || l.vertical === 'crypto-native';
  const stageCap = (l: LeadRow) => maxStageFor(isNative(l) ? 'native' : ((CLUSTER_MAP[l.vertical] ?? 'math') as Cluster));

  // Follow-ups first, oldest stages first
  const followups: { lead: LeadRow; stage: Stage }[] = [];
  for (const stage of [6, 5, 4, 3, 2] as Stage[]) {
    const gap = settings.followup_gap_days?.[String(stage)];
    if (!gap) continue;
    const { data } = await supabase
      .from('nectarpay_leads')
      .select(SELECT)
      .eq('region_id', region)
      .eq('status', 'EMAILED')
      .eq('email_stage', stage - 1)
      .lte('last_emailed_at', cutoff(gap))
      .neq('emails', '{}')
      .eq('compliance_hold', false) // held verticals never send (042)
      .limit(scopeSet ? 2000 : cap);
    for (const l of (data ?? []) as LeadRow[]) {
      if (!inScope(l)) continue;
      if (stage > stageCap(l)) continue;
      followups.push({ lead: l, stage });
    }
  }

  // Fresh e1s: named leads by score, then unnamed by score
  const [{ data: e1Named }, { data: e1Unnamed }] = await Promise.all([
    supabase.from('nectarpay_leads').select(SELECT)
      .eq('region_id', region)
      .eq('status', 'NEW').eq('email_stage', 0).neq('emails', '{}')
      .eq('compliance_hold', false) // held verticals never send (042)
      .not('owner_first_name', 'is', null)
      .order('score', { ascending: false }).limit(scopeSet ? 4000 : cap * 2),
    supabase.from('nectarpay_leads').select(SELECT)
      .eq('region_id', region)
      .eq('status', 'NEW').eq('email_stage', 0).neq('emails', '{}')
      .eq('compliance_hold', false)
      .is('owner_first_name', null)
      .order('score', { ascending: false }).limit(scopeSet ? 4000 : cap * 2),
  ]);

  const jobs: { lead: LeadRow; stage: Stage }[] = [...followups];
  for (const l of [...((e1Named ?? []) as LeadRow[]), ...((e1Unnamed ?? []) as LeadRow[])]) {
    if (!inScope(l)) continue;
    jobs.push({ lead: l, stage: 1 as Stage });
  }

  // One email per inbox per run
  const seen = new Set<string>();
  const eligible = jobs
    .filter((j) => !engagedTokens.has(j.lead.pulse_token))
    .filter((j) => {
      const addr = j.lead.emails?.[0]?.toLowerCase();
      if (!addr || seen.has(addr)) return false;
      seen.add(addr);
      return true;
    });

  // Deal the day's cap round-robin across reps instead of taking the top N
  // by score. Score ordering alone hands the whole batch to whoever owns the
  // densest book, so the other reps get no doors worked that day. Order
  // within each rep is preserved, so their follow-ups still go first.
  const byOwner = new Map<string, { lead: LeadRow; stage: Stage }[]>();
  for (const j of eligible) {
    const key = ownerByPlace.get(j.lead.place_id) ?? '__unassigned';
    const bucket = byOwner.get(key);
    if (bucket) bucket.push(j);
    else byOwner.set(key, [j]);
  }

  const queues = [...byOwner.values()];
  const plan: { lead: LeadRow; stage: Stage }[] = [];
  for (let round = 0; plan.length < cap; round++) {
    let dealt = false;
    for (const q of queues) {
      if (round >= q.length) continue;
      plan.push(q[round]);
      dealt = true;
      if (plan.length >= cap) break;
    }
    if (!dealt) break; // every queue exhausted
  }

  return { plan, repFor, cap };
}

export function planMix(plan: { stage: Stage }[]): Record<string, number> {
  const mix: Record<string, number> = {};
  for (const j of plan) mix[`e${j.stage}`] = (mix[`e${j.stage}`] ?? 0) + 1;
  return mix;
}

export function planPreview(
  plan: { lead: LeadRow; stage: Stage }[],
  repFor: (placeId: string) => Rep
): PlanItem[] {
  return plan.map(({ lead, stage }) => ({
    placeId: lead.place_id,
    stage,
    to: lead.emails[0],
    name: lead.name,
    vertical: lead.vertical,
    band: lead.band,
    repFirst: repFor(lead.place_id).first,
  }));
}

/** Sends today's batch and records the run. */
export async function runCampaign(
  settings: CampaignSettings,
  trigger: 'cron' | 'manual',
  tz: TimeZone = DEFAULT_TZ
): Promise<RunResult> {
  const supabase = serviceClient();

  if (!settings.resend_api_key) return { planned: 0, sent: 0, failed: 0, mix: {}, note: 'No Resend API key configured' };
  if (!settings.physical_address) return { planned: 0, sent: 0, failed: 0, mix: {}, note: 'No physical address (required by CAN-SPAM)' };
  if (!settings.pulse_base_url) return { planned: 0, sent: 0, failed: 0, mix: {}, note: 'No Pulse base URL configured' };

  const { plan, repFor } = await buildPlan(supabase, settings, tz);
  const mix = planMix(plan);
  let sent = 0;
  let failed = 0;

  // Cold campaign mail sends from its OWN subdomain so complaints never
  // touch the reputation that agreements, reminders and rep 1:1 mail ride
  // on. Keeps the rep's local part: eric@nectarpayaz.com sends as
  // eric@go.nectarpayaz.com. Reply-To deliberately stays the ROOT alias -
  // the subdomain has no MX, so replies to it would bounce.
  const campaignFrom = (addr: string) =>
    settings.from_domain ? `${addr.split('@')[0]}@${settings.from_domain}` : addr;

  for (const { lead, stage } of plan) {
    const to = lead.emails[0];
    const rep = repFor(lead.place_id);
    const isNative = !!lead.crypto_native || lead.vertical === 'crypto-native';
    const rendered = renderEmail(
      stage,
      { ...lead, city: cityShort(lead.city), vertical: isNative ? 'crypto-native' : lead.vertical },
      settings.pulse_base_url,
      settings.physical_address,
      rep
    );

    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${settings.resend_api_key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: `${rep.first} at ${settings.from_label ?? 'NectarPay'} <${campaignFrom(rep.fromEmail)}>`,
        to,
        reply_to: settings.reply_to || rep.fromEmail,
        subject: rendered.subject,
        html: rendered.html,
        text: rendered.text,
        // Gmail and Yahoo weigh an unsubscribe HEADER, not just a link in
        // the body. Points at the same Pulse opt-out the copy already uses,
        // so one mechanism drives DNC. No List-Unsubscribe-Post until a real
        // one-click POST endpoint exists - claiming it without one is worse
        // than not claiming it.
        headers: {
          'List-Unsubscribe': [
            lead.pulse_token
              ? `<${(settings.pulse_base_url ?? '').replace(/\/$/, '')}/s/${lead.pulse_token}?i=optout>`
              : null,
            `<mailto:${settings.reply_to || rep.fromEmail}?subject=unsubscribe>`,
          ]
            .filter(Boolean)
            .join(', '),
        },
      }),
    });

    if (!res.ok) {
      failed++;
      console.error('send failed', to, res.status, await res.text());
    } else {
      sent++;
      const stamp = new Date().toISOString();
      await supabase
        .from('nectarpay_leads')
        .update({ status: 'EMAILED', email_stage: stage, last_emailed_at: stamp })
        .eq('place_id', lead.place_id);
      // Sibling locations sharing this inbox count as contacted too
      await supabase
        .from('nectarpay_leads')
        .update({ status: 'EMAILED', email_stage: stage, last_emailed_at: stamp })
        .eq('status', 'NEW')
        .contains('emails', [to]);
    }
    await sleep(settings.send_delay_ms ?? 700);
  }

  await supabase.from('campaign_runs').insert({
    org_id: settings.org_id,
    region_id: settings.region_id,
    trigger,
    planned: plan.length,
    sent,
    failed,
    mix,
  });
  // Keyed on region since 060. Keying on org_id here would stamp every
  // region's campaign as having run because one of them did, and the cron's
  // already-ran-today guard reads this exact column.
  await supabase
    .from('campaign_settings')
    .update({ last_run_at: new Date().toISOString() })
    .eq('region_id', settings.region_id);

  return { planned: plan.length, sent, failed, mix };
}
