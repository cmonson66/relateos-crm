import { type NextRequest } from 'next/server';
import { updateSession } from '@/lib/supabase/middleware';

export async function proxy(request: NextRequest) {
  return await updateSession(request);
}

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static (static files)
     * - _next/image (image optimization)
     * - favicon.ico
     * - public files
     * - api routes
     * - auth callback (must be unauthenticated to reach the hash-flow handler)
     * - welcome page (we authenticate there but reach it via the callback)
     */
    '/((?!_next/static|_next/image|favicon.ico|api|auth/callback|.*\\..*).*)',
  ],
};
